#!/bin/sh
cd ITMXPSolution
git pull
git pull --rebase

cd GRMNITMmm
git pull
git pull --rebase 
cd ..

cd GRMNShareClasses
git pull
git pull --rebase
cd ..

cd GRMNAntLink
git pull
git pull --rebase 
cd ..

cd GRMNMathematical
git pull
git pull --rebase 
cd ..

cd GRMNShareClasses
git pull
git pull --rebase 
cd ..

read -p "Press [Enter] key to end..."