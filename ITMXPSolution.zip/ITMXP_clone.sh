Server=git_Testing

git clone $Server:BCB2009/GRMNAntLink
git clone $Server:BCB2009/GRMNMathematical
git clone $Server:BCB2009/GRMNShareClasses

git clone $Server:BCB2009/GRMNITMmm

git clone $Server:BCB2009/ITMXPSolution

mv GRMNAntLink ITMXPSolution\
mv GRMNMathematical ITMXPSolution\
mv GRMNShareClasses ITMXPSolution\
mv GRMNITMmm ITMXPSolution\

read -p "Press any key to continue..."
