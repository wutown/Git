#!/bin/sh
cd ITMXPSolution
git push origin HEAD:refs/for/master
cd ..
read -p "Press [Enter] key to end..."